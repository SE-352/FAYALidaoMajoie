/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitymanager.jpa.dao;

import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import universitymanager.Personne.Personne;

public class PersonCRUD {
//
//    private static EntityManagerFactory emf;
//    private static EntityManagerFactory em;
//    private static EntityTransaction tx;
//    
//    
//    public PersonCRUD(){
//        emf = Persistence.createEntityManagerFactory("UniversityManagerPU");
//        em = emf.createEntityManager();
//        tx = em.getTran
//    }
//
//    public static Personne findOne(Long personId) {
//        try {
//            tx.begin();
//            em.p
//        } catch (Exception e) {
//        }
//    }
//
//    public static Personne add(Personne person) {
//    }
//
//    public static Personne edit(Personne person) {
//    }
//
//    public static void delete(Personne person) {
//    }
//
//    public static void delete(Long personId) {
//    }
//
//    public static List<Personne> getAll() {
//        Query query = em.createQ
//    }
}
